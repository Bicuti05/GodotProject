from cap import *
big(); get('cheat-set-active', active=0)
def home(): show('home', wait=4)
def level(n, wait=9):
    cmd('level', n, wait=wait - 3); tap(540, 2150, wait=3)
for p in ('logo', 'splash'): hide(p)
for t in ('hint', 'undo', 'rope'):
    level(15); cmd('prop_unlock_preview', t, wait=3); shot('04_Popup/dialog_prop_unlock_%s' % t); tap(540, 1700, wait=4)
cmd('mystery_guide_reset', wait=1); cmd('level', 7, wait=9); shot('05_Banner/guide_hidden_item'); tap(540, 2150)
run('UserState.set_tutorial_done(false)\nreturn 1'.replace('\n', chr(10))); cmd('level', 1, wait=9); shot('05_Banner/guide_tutorial_level1'); get('skip-tutorial')
home(); cmd('daily_checkin_preview', wait=7); shot('06_Meta/daily_checkin_03'); time.sleep(5); shot('06_Meta/daily_checkin_04'); hide('daily_first_win_checkin')
home(); cmd('juice_endless', wait=8); shot('03_Gameplay/gameplay_endless_01'); tap(540, 1700, wait=6); shot('03_Gameplay/gameplay_endless_02')
