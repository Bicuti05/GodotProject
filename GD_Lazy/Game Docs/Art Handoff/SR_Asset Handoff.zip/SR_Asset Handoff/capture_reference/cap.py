"""Drive the local Sort Streak debug API (127.0.0.1:8090) and save full-screen PNGs."""
import urllib.request, urllib.parse, json, base64, time, sys, os
B = 'http://127.0.0.1:8090/pocketsort/api/'
OUT = r'E:\AssetRipper\ClaudeWorkPlace\GD_Lazy\Game Docs\Art Handoff\Full Scenes'


def get(route, **q):
    try: return json.loads(urllib.request.urlopen(B + route + ('?' + urllib.parse.urlencode(q) if q else ''), timeout=30).read())
    except urllib.error.HTTPError as e: return json.loads(e.read() or b'{}') | {'http': e.code}


def cmd(name, args='', wait=3.0): r = get('cmd', name=name, args=args); time.sleep(wait); return r
def show(page, body=None, wait=2.5): r = get('page-show', name=page, **({'body': json.dumps(body)} if body else {})); time.sleep(wait); return r
def hide(page, wait=1.0): get('page-hide', name=page); time.sleep(wait)
def pages(): return get('state').get('pages')


def run(code): return get('exec', code=code)


def shot(name, wait=0.0, out=OUT):
    # the game writes the PNG itself: the HTTP screenshot route drops large responses
    time.sleep(wait); p = os.path.abspath(os.path.join(out, name + '.png')).replace(chr(92), '/'); os.makedirs(os.path.dirname(p), exist_ok=True)
    r = run(chr(10).join(['var i = Engine.get_main_loop().root.get_texture().get_image()',
                          'return [i.save_png("%s"), i.get_width(), i.get_height()]' % p]))
    assert r.get('value', [1])[0] in (0, '0', 0.0) and os.path.getsize(p) > 0, r
    print(name, r['value'][1:], pages(), flush=True)


def big():
    run(chr(10).join(['var w = Engine.get_main_loop().root', 'w.borderless = true', 'w.position = Vector2i(0, 0)', 'w.size = Vector2i(1080, 2340)', 'SafeAreaSim.set_notch(0, 0)', 'return 1'])); time.sleep(2)


def tap(x=540, y=1700, wait=2.0):
    run(chr(10).join(['for down in [true, false]:', '\tvar e = InputEventMouseButton.new()', '\te.button_index = 1', '\te.pressed = down',
                      '\te.position = Vector2(%d, %d)' % (x, y), '\te.global_position = e.position', '\tEngine.get_main_loop().root.push_input(e)', 'return 1'])); time.sleep(wait)
