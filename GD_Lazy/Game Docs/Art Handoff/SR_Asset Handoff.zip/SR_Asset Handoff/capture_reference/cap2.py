from cap import *
big(); get('cheat-set-active', active=0)
for p in ('finish', 'setting', 'confirm'): hide(p, 0.2)
show('home', wait=5); shot('02_Home/home_main')
for n, name in ((1, 'level1_start'), (3, 'level3_start'), (7, 'level7_hidden'), (12, 'level12_locked'), (15, 'level15_hard'), (40, 'level40_hard')):
    cmd('level', n, wait=5)
    if n >= 15: shot('04_Popup/streak_popup_level%d' % n)
    tap(540, 2000, wait=1); time.sleep(8)
    shot('03_Gameplay/gameplay_' + name)
