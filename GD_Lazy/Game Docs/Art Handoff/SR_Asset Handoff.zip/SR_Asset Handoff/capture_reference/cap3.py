from cap import *
import json
def lv(n=15, wait=11):
    cmd('level', n, wait=4); tap(540, 2000, wait=1); time.sleep(wait - 5)
lv(15); 
tap(425, 1990, wait=1.5); shot('03_Gameplay/helper_hint')
tap(650, 1990, wait=2.5); shot('03_Gameplay/helper_extra_rope')
cmd('complete_column', wait=0.8); shot('03_Gameplay/helper_fill_column_motion'); time.sleep(4); shot('03_Gameplay/helper_fill_column_after')
cmd('last_cup', wait=3); shot('03_Gameplay/gameplay_last_step')
cmd('win_round', wait=1.2); shot('04_Popup/win_motion_01'); time.sleep(2); shot('04_Popup/win_motion_02'); time.sleep(5); shot('04_Popup/win_finish'); print(pages())
hide('finish'); show('home', wait=4)
lv(15); cmd('sort_die', wait=1.5); shot('04_Popup/dead_01'); time.sleep(3); shot('04_Popup/dead_02'); hide('game_dead_toast')
for i in (1, 2, 3):
    lv(8); cmd('streak_popup_%d' % i, wait=1.6); shot('04_Popup/streak_popup_%d' % i); time.sleep(3)
for name, c, w in (('gameplay_8_columns', 'eight_columns', 9), ('gameplay_long_rope', 'long_rope', 9), ('gameplay_sunlight_pot_new', 'sunlight_pot_level', 9),
                   ('gameplay_bonus_start', 'bonus_start_test', 9), ('gameplay_bonus_level', 'bonus_level', 10), ('gameplay_challenge', 'challenge_time', 9), ('gameplay_endless', 'juice_endless', 10)):
    show('home', wait=3); r = cmd(c, wait=2.0); shot('05_Banner/' + name + '_intro'); tap(540, 2150, wait=1); time.sleep(w - 3); shot('03_Gameplay/' + name)
cmd('juice_json_off', wait=2)
S = json.load(open(r'E:\AssetRipper\ClaudeWorkPlace\SortStreak\out\GodotProject\assets\game\juice_sunlight_levels.json', encoding='utf8'))
for k, i in enumerate((0, 150, 330)):
    show('home', wait=3); get('juice-level', clear=1); print(get('juice-level', body=json.dumps(S[i]['raw'], ensure_ascii=False), **{'as': 20 + k})); time.sleep(5); tap(540, 2000, wait=1); time.sleep(6); shot('03_Gameplay/gameplay_sunlight_ice_%d' % (k + 1))
get('juice-level', clear=1)
