from cap import *
big(); get('cheat-set-active', active=0)
def home(): show('home', wait=4)
home(); cmd('bonus_level', wait=5); tap(540, 1945, wait=3); shot('05_Banner/banner_bonus_motion'); time.sleep(7); shot('03_Gameplay/gameplay_bonus_level')
cmd('win_round', wait=6); shot('04_Popup/bonus_level_win_01'); time.sleep(5); shot('04_Popup/bonus_level_win_02')
home()
for p in ('setting', 'privacy', 'confirm', 'reset_confirm', 'avatar_select', 'rank_introduction', 'rank_new_season', 'rank_change', 'rank_season_win',
          'new_scene', 'prop_unlock', 'special_challenge_reward', 'timed_endless_reward', 'daily_first_win_checkin', 'finish_ad_reward', 'loading'):
    try:
        r = show(p, wait=3.5); print(p, r.get('result')); shot('04_Popup/dialog_%s' % p)
    finally:
        hide(p)
for p in ('rank', 'logo', 'splash'):
    r = show(p, wait=2.5); print(p, r.get('result')); shot('01_Logo/page_%s' % p if p != 'rank' else '06_Meta/page_rank'); home()
