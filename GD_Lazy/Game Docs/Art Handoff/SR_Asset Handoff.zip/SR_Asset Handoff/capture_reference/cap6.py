from cap import *
big(); get('cheat-set-active', active=0)
def home(): show('home', wait=4)
def level(n, wait=9):
    cmd('level', n, wait=wait - 3); tap(540, 2150, wait=3)
for name in ('hard_banner', 'super_hard_banner', 'streak_banner', 'bonus_banner', 'challenge_banner', 'good_luck', 'smart_move', 'combo_preview', 'combo_fullscreen_fx'):
    level(15); cmd(name, wait=1.0); shot('05_Banner/banner_%s_01' % name); time.sleep(0.8); shot('05_Banner/banner_%s_02' % name); time.sleep(3)
cmd('next_super_hard', wait=1); level(16, 12); shot('03_Gameplay/gameplay_super_hard')
cmd('prop_unlock_preview', wait=3); shot('04_Popup/dialog_prop_unlock'); tap(540, 1900, wait=3)
level(15); cmd('daily_checkin_preview', wait=3); shot('06_Meta/daily_checkin_01'); time.sleep(3); shot('06_Meta/daily_checkin_02')
level(15); cmd('daily_first_round', wait=1); level(15); cmd('win_round', wait=8)
for i in range(5):
    shot('06_Meta/first_win_flow_%d' % (i + 1)); tap(540, 2100, wait=4)
home(); level(25); cmd('last_cup', wait=3); cmd('win_round', wait=8)
for i in range(6):
    shot('06_Meta/chapter_end_flow_%d' % (i + 1)); tap(540, 2100, wait=4.5)
