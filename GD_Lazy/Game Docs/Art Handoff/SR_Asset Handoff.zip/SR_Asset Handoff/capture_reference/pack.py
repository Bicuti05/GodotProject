"""Rename the captures to final names, write INDEX.md, zip (PNG kept on disk, JPG inside the zip for chat)."""
import os, glob, io, zipfile
from PIL import Image
from cap import OUT

G = 'scripts/main/pages/game/juice_game_page.tscn'
H = 'scripts/main/pages/home/home_page.tscn'
P, D = 'scripts/main/pages/', 'scripts/main/dialogs/'
R, C, X = 'Luồng thật', 'Lệnh debug', 'Mở trực tiếp'
M = []   # (old, new, screen, how, kind, source)


def a(old, new, screen, how, kind, src): M.append((old, new, screen, how, kind, src))


a('01_Logo/page_logo', '01_Logo/logo_oakever', 'Logo hãng', 'page-show logo', X, P + 'logo/logo_page.tscn')
a('01_Logo/page_splash', '01_Logo/splash_loading', 'Splash / tải game', 'page-show splash', X, P + 'splash/splash_page.tscn')
a('02_Home/home_main', '02_Home/home_scene1', 'Home, Scene 1 đang ghép', 'page-show home', R, H)
a('02_Home/home_current', '02_Home/home_scene2', 'Home, nền scene mới', 'page-show home', R, H)
a('02_Home/home_bonus_level', '02_Home/home_bonus_level', 'Home, nút Bonus Level', 'bonus_level', C, H)
a('06_Meta/first_win_flow_5', '02_Home/home_super_hard', 'Home, nút Super Hard', 'sau khi thắng, next_super_hard', C, H)
a('06_Meta/chapter_end_flow_5', '02_Home/home_scene_complete', 'Home, scene ghép đủ 25/25', 'thắng level 25', C, H)
for n, s in (('level1_start', 'Level 1'), ('level3_start', 'Level 3'), ('level7_hidden', 'Level 7, hidden'),
             ('level12_locked', 'Level 12, locked rope'), ('level15_hard', 'Level 15, Hard'), ('level40_hard', 'Level 40, Hard')):
    a('03_Gameplay/gameplay_' + n, '03_Gameplay/gameplay_' + n, s, 'level n', C, G)
a('03_Gameplay/gameplay_super_hard', '03_Gameplay/gameplay_super_hard', 'Super Hard', 'next_super_hard + level 16', C, G)
a('03_Gameplay/gameplay_8_columns', '03_Gameplay/gameplay_test_8_columns', 'Bàn test 8 rope', 'eight_columns', C, G)
a('03_Gameplay/gameplay_long_rope', '03_Gameplay/gameplay_test_long_rope', 'Bàn test rope dài', 'long_rope', C, G)
a('03_Gameplay/gameplay_challenge', '03_Gameplay/gameplay_test_challenge', 'Bàn test Challenge', 'challenge_time', C, G)
a('03_Gameplay/gameplay_bonus_start', '03_Gameplay/gameplay_test_golden_pig', 'Bàn test Golden Pig', 'bonus_start_test', C, G)
for i in (1, 2, 3):
    n = '03_Gameplay/gameplay_sunlight_ice_%d' % i
    a(n, n, 'Sunlight + băng, level mẫu %d' % i, 'API juice-level, juice_sunlight_levels.json', C, G)
a('03_Gameplay/helper_hint', '03_Gameplay/helper_hint', 'Helper Hint', 'bấm nút Hint', R, G)
a('03_Gameplay/helper_extra_rope', '03_Gameplay/helper_extra_rope', 'Helper Extra Rope', 'bấm nút Rope', R, G)
a('03_Gameplay/helper_fill_column_motion', '03_Gameplay/helper_fill_container_motion', 'Fill Container đang chạy', 'complete_column', C, G)
a('03_Gameplay/helper_fill_column_after', '03_Gameplay/helper_fill_container_after', 'Fill Container xong', 'complete_column', C, G)
a('03_Gameplay/gameplay_last_step', '03_Gameplay/gameplay_last_step', 'Còn một nước là thắng', 'last_cup', C, G)
a('04_Popup/win_motion_01', '04_Popup/win_motion_01', 'Thắng: xu bay', 'win_round', C, G)
a('04_Popup/win_motion_02', '04_Popup/win_motion_02', 'Thắng: vật phẩm rank bay', 'win_round', C, G)
RF = P + 'rank_game_finish/rank_game_finish_page.tscn'
a('04_Popup/rank_game_finish', '04_Popup/rank_finish_enter', 'Rank cuối ván, đang vào', 'win_round', C, RF)
a('04_Popup/finish_flow_1', '04_Popup/rank_finish_continue', 'Rank cuối ván, nút Continue', 'win_round', C, RF)
a('06_Meta/chapter_end_flow_2', '04_Popup/rank_finish_climb', 'Rank cuối ván, tăng hạng', 'thắng level 25', C, RF)
a('04_Popup/finish_flow_2', '04_Popup/finish_result', 'Kết quả thắng', 'win_round', C, D + 'finish/finish_dialog.tscn')
a('06_Meta/chapter_end_flow_3', '04_Popup/finish_result_fantastic', 'Kết quả thắng, lời khen khác', 'thắng level 25', C, D + 'finish/finish_dialog.tscn')
for i in (1, 2):
    a('04_Popup/dead_0%d' % i, '04_Popup/dead_no_moves_%d' % i, 'Hết nước đi', 'sort_die', C, D + 'game_dead_toast/game_dead_toast.tscn')
for i in (3, 7, 12):
    a('04_Popup/streak_popup_%d' % i, '04_Popup/streak_%d' % i, 'Popup Streak %d' % i, 'streak_popup_1 %d' % i, C, G)
for t in ('hint', 'undo', 'rope'):
    a('04_Popup/dialog_prop_unlock_' + t, '04_Popup/helper_unlock_' + t, 'Mở khóa helper ' + t, 'prop_unlock_preview ' + t, C, D + 'prop_unlock/prop_unlock_dialog.tscn')
for n, s, src in (('setting', 'Settings', 'settings/settings_dialog'), ('privacy', 'Privacy', 'privacy/privacy_dialog'),
                  ('confirm', 'Xác nhận thoát level', 'confirm/confirm_dialog'), ('reset_confirm', 'Xác nhận Reset', 'reset_confirm/reset_confirm_dialog'),
                  ('avatar_select', 'Profile / chọn avatar', 'avatar_select/avatar_select_dialog'),
                  ('rank_introduction', 'Giới thiệu Rank', 'rank_introduction/rank_introduction_dialog'),
                  ('rank_new_season', 'Season mới', 'rank_new_season/rank_new_season_dialog'), ('rank_change', 'Kết thúc season', 'rank_change/rank_change_dialog'),
                  ('rank_season_win', 'Thắng season', 'rank_season_win/rank_season_win_page'),
                  ('special_challenge_reward', 'Thưởng Special Challenge', 'special_challenge_reward/special_challenge_reward_dialog'),
                  ('timed_endless_reward', 'Thưởng Endless', 'timed_endless_reward/timed_endless_reward_dialog')):
    a('04_Popup/dialog_' + n, '04_Popup/dialog_' + n, s, 'page-show ' + n, X, D + src + '.tscn')
for n, s in (('hard_banner', 'Banner Hard'), ('super_hard_banner', 'Banner Super Hard'), ('bonus_banner', 'Banner Bonus Level'),
             ('challenge_banner', 'Banner Challenge'), ('streak_banner', 'Banner Streak'), ('good_luck', 'Chữ Good Luck'),
             ('smart_move', 'Chữ Smart Move'), ('combo_preview', 'Chữ Combo'), ('combo_fullscreen_fx', 'Combo toàn màn')):
    for i in (1, 2):
        a('05_Banner/banner_%s_0%d' % (n, i), '05_Banner/banner_%s_%d' % (n.replace('_banner', ''), i), '%s, khung %d' % (s, i), n, C, G)
for i in (1, 2):
    a('05_Banner/banner_streak_trophy_motion_0%d' % i, '05_Banner/banner_streak_trophy_%d' % i, 'Cúp Streak đang vào, khung %d' % i, 'vào level khi đang có streak', C, G)
a('05_Banner/guide_check', '05_Banner/guide_hidden', 'Hướng dẫn hidden', 'mở game với save đang ở level 7', R, G)
a('05_Banner/guide_locked_rope', '05_Banner/guide_locked_rope', 'Hướng dẫn locked rope', 'vào level sau bonus_level', C, G)
a('05_Banner/guide_sunlight_ice', '05_Banner/guide_sunlight_ice', 'Hướng dẫn Sunlight / băng', 'sunlight_pot_level', C, G)
a('06_Meta/page_rank', '06_Meta/rank_page', 'Trang Rank', 'page-show rank', X, P + 'rank/rank_page.tscn')
for i, s in enumerate(('vào màn', 'đang mở quà', 'nhận xu', 'hoàn tất'), 1):
    a('06_Meta/daily_checkin_0%d' % i, '06_Meta/daily_checkin_%d' % i, 'Daily Check-in, ' + s, 'daily_checkin_preview', C, D + 'daily_first_win_checkin/daily_first_win_checkin_dialog.tscn')
a('06_Meta/new_scene_unlock', '06_Meta/new_scene_unlock', 'Mở scene mới', 'thắng level 25', C, 'scripts/gameplay/outer_loop/view/new_scene_page.tscn')


def path(n): return os.path.join(OUT, n.replace('/', os.sep) + '.png')


missing = [m[0] for m in M if not os.path.exists(path(m[0])) and not os.path.exists(path(m[1]))]
assert not missing, missing
for m in M:
    if m[0] != m[1] and os.path.exists(path(m[0])): os.replace(path(m[0]), path(m[1]))
keep = {path(m[1]) for m in M}; assert len(keep) == len(M)
drop = [f for f in glob.glob(os.path.join(OUT, '*', '*.png')) if f not in keep]
for f in drop: os.remove(f)
print('dropped', [os.path.basename(f) for f in drop])
for f in keep: assert Image.open(f).size == (1080, 2340), f

L = ['# Sort Streak: Full Scenes (art tham khảo cho Sweet Rope)', '',
     'Chỉ dùng để tham khảo. Không đưa asset của Sort Streak vào sản phẩm Sweet Rope.', '',
     'Ảnh chụp từ game đang chạy trên PC (Sort Streak 1.0.10 bản giải nén, Godot 4.6.1 + Spine), 1080×2340, safe area đặt bằng 0, không có banner quảng cáo. Tên người chơi và bảng xếp hạng là dữ liệu của bản chạy thử.', '',
     '- **Luồng thật**: thao tác như người chơi.',
     '- **Lệnh debug**: tạo trạng thái bằng lệnh debug có sẵn của game, sau đó game tự vẽ. Bàn "test" không phải level thật.',
     '- **Mở trực tiếp**: mở màn không kèm dữ liệu. Số và chữ có thể là giá trị giữ chỗ (ví dụ hạng `#-1`, thưởng `x0`), chưa xác thực.', '',
     '| File | Màn / trạng thái | Cách mở | Loại | Scene |', '|---|---|---|---|---|']
L += ['| `%s.png` | %s | %s | %s | `%s` |' % (m[1], m[2], m[3], m[4], m[5]) for m in sorted(M, key=lambda m: m[1])]
L += ['', '## Chưa lấy được', '',
      '- Màn chơi Endless: game ngừng phản hồi khi mở bằng `juice_endless` (thử 2 lần). Chỉ có popup thưởng Endless.',
      '- Popup Finish Ad Reward và lớp Loading: mở trực tiếp chỉ ra màn trống.',
      '- Hướng dẫn bàn tay ở level 1.', '- Băng kiểu chặn ghép (blockConnection) và Container đóng băng.',
      '- Thua do hết giờ, shop, banner quảng cáo.', '- Animation: chỉ có vài khung tĩnh, không có video.']
text = '\n'.join(L) + '\n'
open(os.path.join(OUT, 'INDEX.md'), 'w', encoding='utf8').write(text)
Z = os.path.join(os.path.dirname(OUT), 'SS_Full Scenes.zip')
with zipfile.ZipFile(Z, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('INDEX.md', text.replace('.png`', '.jpg`'))
    for f in sorted(keep):
        b = io.BytesIO(); Image.open(f).convert('RGB').save(b, 'JPEG', quality=92)
        z.writestr(os.path.relpath(f, OUT).replace(os.sep, '/')[:-4] + '.jpg', b.getvalue(), compress_type=zipfile.ZIP_STORED)
with zipfile.ZipFile(Z) as z:
    assert z.testzip() is None and len(z.namelist()) == len(M) + 1
print(len(M), 'images', round(sum(os.path.getsize(f) for f in keep) / 1e6), 'MB png;', 'zip', round(os.path.getsize(Z) / 1e6, 1), 'MB')
