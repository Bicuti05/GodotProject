from cap import *
get('skip-tutorial')
shot('03_Gameplay/gameplay_hidden_guide_level7')
show('home', wait=4); shot('02_Home/home_main')
for n in (1, 3, 12, 15, 25, 40):
    cmd('level', str(n), wait=7); shot('03_Gameplay/gameplay_level%d' % n)
