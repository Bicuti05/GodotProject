from cap import *
import json
big(); get('cheat-set-active', active=0)
S = json.load(open(r'E:\AssetRipper\ClaudeWorkPlace\SortStreak\out\GodotProject\assets\game\juice_sunlight_levels.json', encoding='utf8'))
for k, i in enumerate((0, 150, 330)):
    show('home', wait=3); get('juice-level', clear=1); print(get('juice-level', body=json.dumps(S[i]['raw'], ensure_ascii=False), **{'as': 20 + k})); time.sleep(6); tap(540, 2150, wait=1); time.sleep(6); shot('03_Gameplay/gameplay_sunlight_ice_%d' % (k + 1))
get('juice-level', clear=1)
cmd('level', 15, wait=10); cmd('last_cup', wait=3); cmd('win_round', wait=8); shot('04_Popup/rank_game_finish')
for i in range(3):
    tap(540, 2150, wait=5); shot('04_Popup/finish_flow_%d' % (i + 1))
    if 'finish' not in pages() and 'rank_game_finish' not in pages(): break
